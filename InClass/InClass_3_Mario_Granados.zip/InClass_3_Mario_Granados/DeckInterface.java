package InClass.InClass_3_Mario_Granados;

public interface DeckInterface {
    public void push(String Card);

    public String pop();

    public boolean isEmpty();

    public void shuffle();

}